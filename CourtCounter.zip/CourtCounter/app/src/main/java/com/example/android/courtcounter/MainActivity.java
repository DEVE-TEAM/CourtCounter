package com.example.android.courtcounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    int scoreForTeamA;

    /**
     * Add three points for team A
     */
    public void threePointsTeamA(View V) {
        Button too = (Button) findViewById(R.id.three_Points);
        scoreForTeamA = scoreForTeamA + 3;
        displayForTeamA(scoreForTeamA);
    }

    /**
     * Add tow points for team A
     */
    public void towPointsTeamA(View V) {
        Button too = (Button) findViewById(R.id.tow_Points);
        scoreForTeamA = scoreForTeamA + 2;
        displayForTeamA(scoreForTeamA);
    }

    /**
     * Free throw for team A
     */
    public void freePointsTeamA(View V) {
        Button too = (Button) findViewById(R.id.free_Points);
        scoreForTeamA = scoreForTeamA + 1;
        displayForTeamA(scoreForTeamA);
    }

    /**
     * Displays the given score for Team A.
     */
    public void displayForTeamA(int score) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score);
        scoreView.setText(String.valueOf(score));
    }

    /**
     * Start code for team B
     */

    int scoreForTeamB;

    /**
     * Add three points for team B
     */

    public void threePointsTeamB(View V) {
        Button too = (Button) findViewById(R.id.three_Points_B);
        scoreForTeamB = scoreForTeamB + 3;
        displayForTeamB(scoreForTeamB);

    }

    /**
     * Add tow points for team B
     */
    public void towPointsTeamB(View V) {
        Button too = (Button) findViewById(R.id.tow_Points_B);
        scoreForTeamB = scoreForTeamB + 2;
        displayForTeamB(scoreForTeamB);
    }

    /**
     * Add Free throw for team B
     */
    public void freePointsTeamB(View V) {
        Button too = (Button) findViewById(R.id.free_Points_B);
        scoreForTeamB = scoreForTeamB + 1;
        displayForTeamB(scoreForTeamB);
    }

    /**
     * Displays the given score for Team B.
     */
    public void displayForTeamB(int scoreB) {
        TextView scoreView = (TextView) findViewById(R.id.team_a_score_B);
        scoreView.setText(String.valueOf(scoreB));
    }

    /**
     * reset the value to zero for team A and B
     */
    public void reset(View v) {
        scoreForTeamA = 0;
        scoreForTeamB = 0;
        displayForTeamA(scoreForTeamA);
        displayForTeamB(scoreForTeamB);
    }}
